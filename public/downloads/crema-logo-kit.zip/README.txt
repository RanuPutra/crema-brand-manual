CREMA — Master Logo Package
Brand System by Proiectum Studio (https://proiectum.studio)

Contents:
- crema-logo-espresso.svg       Primary dark Roasted Espresso (#24110C) vector
- crema-logo-cream.svg          Steamed Linen (#F4EFE6) reversed vector
- crema-logo-white.svg          Pure White (#FFFFFF) vector for dark & gradient posters
- crema-logo-outline.svg        White outline stroke vector for glass & editorial overlays
- crema-logo-espresso-2400w.png Transparent 2400px PNG (dark)
- crema-logo-white-2400w.png    Transparent 2400px PNG (white)

Usage Rules:
1. Maintain minimum 1x cap-height clearspace around the wordmark.
2. Never distort, apply heavy drop shadows, or enclose inside unapproved badges.
3. Use #24110C on pale cafe surfaces and #FFFFFF / #F4EFE6 on Warm Timber, Espresso, or gradients.
