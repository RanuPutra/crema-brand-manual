// CREMA Tailwind CSS Preset — Brand System by Proiectum Studio
export default {
  theme: {
    extend: {
      colors: {
        crema: {
          canvas: "#F4EFE6",
          ink: "#1B120E",
          muted: "#594A42",
          timber: "#8C4E29",
          milk: "#EBE4D7",
          amber: "#DDA04B",
          espresso: "#24110C",
        },
      },
      fontFamily: {
        display: ["Rubik", "sans-serif"],
        sans: ["Geist", "sans-serif"],
        mono: ["Geist Mono", "monospace"],
      },
    },
  },
};
